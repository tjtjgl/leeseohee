package bookmarket;

public class Run {

	public static void main(String[] args) {
		new BookMenu().mainMenu();
	}

}
